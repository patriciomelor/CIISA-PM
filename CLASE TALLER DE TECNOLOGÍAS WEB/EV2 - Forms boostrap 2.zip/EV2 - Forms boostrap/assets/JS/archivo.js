var input = document.getElementById("Nombre");
input.placeholder = "Ingresa un nombre";

function NombreFuncion() {
    alert("Pagina web para ciisa")


}

function NombreBoton() {

    document.getElementById("boton").classList.toggle('margin')
}