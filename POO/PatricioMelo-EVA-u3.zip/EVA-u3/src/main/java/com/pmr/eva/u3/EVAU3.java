/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.pmr.eva.u3;
import java.util.Random;

/**
 *
 * @author lyvra
 */
public class EVAU3 {

    public static void main(String[] args) {
        int[][] encuestaData = generarEncuesta(10);

        calcularPorcentajesGenero(encuestaData);
        calcularPorcentajesTrabajo(encuestaData);
        calcularSueldoPromedio(encuestaData);
    }

    // Generar datos aleatorios para la encuesta
    public static int[][] generarEncuesta(int numPersonas) {
        int[][] data = new int[numPersonas][3];
        Random random = new Random();

        for (int i = 0; i < numPersonas; i++) {
            data[i][0] = random.nextInt(3) + 1; // Género
            data[i][1] = random.nextInt(2) + 1; // Trabaja
            data[i][2] = data[i][1] == 1 ? random.nextInt(2201) + 300 : 0; // Remuneración
        }

        return data;
    }

    // Calcular porcentajes de género
    public static void calcularPorcentajesGenero(int[][] data) {
        int totalPersonas = data.length;
        int hombres = 0, mujeres = 0, otros = 0;

        for (int i = 0; i < totalPersonas; i++) {
            switch (data[i][0]) {
                case 1: mujeres++; break;
                case 2: hombres++; break;
                case 3: otros++; break;
            }
        }

        double porcentajeMujeres = (double) mujeres / totalPersonas * 100;
        double porcentajeHombres = (double) hombres / totalPersonas * 100;
        double porcentajeOtros = (double) otros / totalPersonas * 100;

        System.out.println("Porcentaje de mujeres: " + porcentajeMujeres + "%");
        System.out.println("Porcentaje de hombres: " + porcentajeHombres + "%");
        System.out.println("Porcentaje de otros géneros: " + porcentajeOtros + "%");
    }

    // Calcular porcentajes de trabajo
    public static void calcularPorcentajesTrabajo(int[][] data) {
        int totalPersonas = data.length;
        int trabajaHombres = 0, trabajaMujeres = 0, trabajaOtros = 0;

        for (int i = 0; i < totalPersonas; i++) {
            if (data[i][1] == 1) {
                switch (data[i][0]) {
                    case 1: trabajaMujeres++; break;
                    case 2: trabajaHombres++; break;
                    case 3: trabajaOtros++; break;
                }
            }
        }

        double porcentajeTrabajaMujeres = (double) trabajaMujeres / totalPersonas * 100;
        double porcentajeTrabajaHombres = (double) trabajaHombres / totalPersonas * 100;
        double porcentajeTrabajaOtros = (double) trabajaOtros / totalPersonas * 100;

        System.out.println("Porcentaje de mujeres que trabajan: " + porcentajeTrabajaMujeres + "%");
        System.out.println("Porcentaje de hombres que trabajan: " + porcentajeTrabajaHombres + "%");
        System.out.println("Porcentaje de otros géneros que trabajan: " + porcentajeTrabajaOtros + "%");
    }

    // Calcular sueldo promedio
    public static void calcularSueldoPromedio(int[][] data) {
        int totalPersonas = data.length;
        int totalHombres = 0, totalMujeres = 0, totalOtros = 0;
        int sueldoHombres = 0, sueldoMujeres = 0, sueldoOtros = 0;

        for (int i = 0; i < totalPersonas; i++) {
            int genero = data[i][0];
            int trabaja = data[i][1];
            int sueldo = data[i][2];

            if (trabaja == 1) {
                switch (genero) {
                    case 1:
                        totalMujeres++;
                        sueldoMujeres += sueldo;
                        break;
                    case 2:
                        totalHombres++;
                        sueldoHombres += sueldo;
                        break;
                    case 3:
                        totalOtros++;
                        sueldoOtros += sueldo;
                        break;
                }
            }
        }

        double promedioSueldoHombres = (double) sueldoHombres / totalHombres;
        double promedioSueldoMujeres = (double) sueldoMujeres / totalMujeres;
        double promedioSueldoOtros = (double) sueldoOtros / totalOtros;

        System.out.println("Sueldo promedio de hombres que trabajan: " + promedioSueldoHombres);
        System.out.println("Sueldo promedio de mujeres que trabajan: " + promedioSueldoMujeres);
        System.out.println("Sueldo promedio de otros géneros que trabajan: " + promedioSueldoOtros);


    }
}
